using UnityEngine;
using UnityEngine.SceneManagement;

public class Clock_Level_01 : MonoBehaviour
{
    // Variables
    public TextMesh textArea;
    private int clock;


    // Update is called once per frame
    private void Update()
    {
        clock = Time.frameCount / 35;
        textArea.text = " " + clock;
    }
}
