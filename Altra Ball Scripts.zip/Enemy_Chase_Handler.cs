using UnityEngine;
using UnityEngine.SceneManagement;

public class Enemy_Chase_Handler : MonoBehaviour
{
    public Transform enemy;
    public Rigidbody body;
    private float vectorX;
    private float vectorY;
    private float vectorZ;
    private float speed = 1.25f;

    //Update called per frame per second
    void FixedUpdate()
    {
        //Vectors for enemy controls
        vectorX = enemy.position.x - transform.position.x;
        vectorY = enemy.position.y - transform.position.y;
        vectorZ = enemy.position.z - transform.position.z;

        //Enemy follows player
       if(enemy){
           float dist = Vector3.Distance(enemy.position, transform.position);
           if(dist <= 7f){
               body.velocity = new Vector3(vectorX * speed, vectorY * speed, vectorZ * speed);
           }
       }
    }
}
