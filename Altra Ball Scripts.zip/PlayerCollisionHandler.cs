using UnityEngine;
using UnityEngine.SceneManagement;


public class PlayerCollisionHandler : MonoBehaviour
{
    //Variables
    public Transform player;
    public TextMesh ui;
    private int count;

    //Initialize
    private void Start(){
        ui.text = " ";
    }
    

    //Collision enter handler
    private void OnCollisionEnter(Collision other){
        if(other.collider.tag == "Enemy" && count <= 1){
            count = count++;
            FindObjectOfType<AudioManager>().Play("PlayerDeath");
            ui.text = "Player Has Died ...";
            Invoke("Reset", 2);
        }
        if(other.collider.tag == "Floor" && count <= 1){
            count = count++;
            FindObjectOfType<AudioManager>().Play("PlayerDeath");
            ui.text = "Player Has Died ...";
            Invoke("Reset", 2);
        }
    }

    //Trigger enter handler
    private void OnTriggerEnter(Collider other){
        if(other.GetComponent<Collider>().isTrigger == true){
            other.GetComponent<MeshRenderer>().enabled = false;
            other.GetComponent<Collider>().enabled = false;
            FindObjectOfType<AudioManager>().Play("Vanish");
        }
    }
    
    //Reset function
    private void Reset(){
        count = count--;
        ui.text = " ";
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
