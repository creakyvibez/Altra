using UnityEngine;
using UnityEngine.SceneManagement;

public class Level_Handler : MonoBehaviour
{
    //Variables
    public TextMesh ui;

    //Initialize
    private void Start(){
        ui.text = " ";
    }

    //Level selection based on collision name
    private void OnCollisionEnter(Collision checkpoint){
        //checks that the checkpoint is named accordingly
        if(checkpoint.collider.name == "Start_Game"){
            ui.text = "Level Complete!";
            FindObjectOfType<AudioManager>().Play("Checkpoint");
            SceneManager.LoadScene("Level01");
        }
        if(checkpoint.collider.name == "Checkpoint_Level01"){
            ui.text = "Level Complete!";
            FindObjectOfType<AudioManager>().Play("Checkpoint");
            SceneManager.LoadScene("Level02");
        }
        if(checkpoint.collider.name == "Checkpoint_Level02"){
            ui.text = "Level Complete!";
            FindObjectOfType<AudioManager>().Play("Checkpoint");
            SceneManager.LoadScene("Level03");
        }
        if(checkpoint.collider.name == "Checkpoint_Level03"){
            ui.text = "Level Complete!";
            FindObjectOfType<AudioManager>().Play("Checkpoint");
            SceneManager.LoadScene("Level04");
        }
        if(checkpoint.collider.name == "Checkpoint_Level04"){
            ui.text = "Level Complete!";
            FindObjectOfType<AudioManager>().Play("Checkpoint");
            SceneManager.LoadScene("Level05");
        }
    }

    private void Update(){
        if(Input.GetKey("escape")){
            SceneManager.LoadScene("StartScreen");
        }
        /*
        if(Input.GetKey(KeyCode.R)){
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
        */
    }
}
