﻿using UnityEngine;

public class FollowPlayer : MonoBehaviour
{

    public Transform player;
    private Vector3 offset;
    
    private void Start(){
        offset = new Vector3(0,2.5f,-10f);
    }
    
    // Update is called once per frame
    private void Update()
    {
        transform.position = player.position + offset;
        
    }
}
