using UnityEngine;

public class InputController : MonoBehaviour
{
    [SerializeField] private Camera cam;
    [SerializeField] private Transform target;
    private Vector3 offset = new Vector3(0,2,-8);

    private Vector3 previousPosition;

    // Update is called once per frame
    void Update()
    {
        cam.transform.position = target.position + offset;
        if(Input.GetMouseButtonDown(0))
        {
            previousPosition = cam.ScreenToViewportPoint(Input.mousePosition);
        }

        if(Input.GetMouseButton(0))
        {
            Vector3 direction = previousPosition - cam.ScreenToViewportPoint(Input.mousePosition);
            //cam.transform.position = target.position + offset;
            cam.transform.Rotate(new Vector3(1,0,0), direction.y * 10);
            cam.transform.Rotate(new Vector3(0,1,0), -direction.x * 10, Space.World);
            cam.transform.Translate(0,0,-8);
        }
    }
}
