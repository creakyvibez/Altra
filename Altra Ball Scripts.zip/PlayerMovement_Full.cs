using UnityEngine;

public class PlayerMovement_Full : MonoBehaviour
{
    //Variables
    private Rigidbody body;
    private int moveSpeed = 5;

    //Input Variables
    private int rightDir = 5;
    private int leftDir = -5;
    private int forwardDir = 5;
    private int backwardDir = -5;
    private int jumpDir = 2;
    private bool jumped;

    // Initialization
    private void Start(){
        body = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        //Makes player move forward
        if(Input.GetKey(KeyCode.W)){
                body.AddForce(0, 0, forwardDir * moveSpeed);
                if(Input.GetKeyDown(KeyCode.W)){
                    FindObjectOfType<AudioManager>().Play("Moving");
                }
        }

        //Makes character move backward
        if(Input.GetKey(KeyCode.S)){
                body.AddForce(0, 0, backwardDir * moveSpeed);
                if(Input.GetKeyDown(KeyCode.S)){
                    FindObjectOfType<AudioManager>().Play("Moving");
                }
        }

        //Makes character move right
        if(Input.GetKey(KeyCode.D)){
                body.AddForce(rightDir * moveSpeed, 0, 0);
                if(Input.GetKeyDown(KeyCode.D)){
                    FindObjectOfType<AudioManager>().Play("Moving");
                }
        }

        //Makes character move left
        if(Input.GetKey(KeyCode.A)){
                body.AddForce(leftDir * moveSpeed, 0, 0);
                if(Input.GetKeyDown(KeyCode.A)){
                    FindObjectOfType<AudioManager>().Play("Moving");
                }
        }

        //Makes player move forward with arrow key
        if(Input.GetKey("up")){
                body.AddForce(0, 0, forwardDir * moveSpeed);
                if(Input.GetKeyDown("up")){
                    FindObjectOfType<AudioManager>().Play("Moving");
                }
        }

        //Makes character move backward with arrow key
        if(Input.GetKey("down")){
                body.AddForce(0, 0, backwardDir * moveSpeed);
                if(Input.GetKeyDown("down")){
                    FindObjectOfType<AudioManager>().Play("Moving");
                }
        }
        
        //Makes character move right with arrow key
        if(Input.GetKey("right")){
                body.AddForce(rightDir * moveSpeed, 0, 0);
                if(Input.GetKeyDown("right")){
                    FindObjectOfType<AudioManager>().Play("Moving");
                }
        }

        //Makes character move left with arrow key
        if(Input.GetKey("left")){
                body.AddForce(leftDir * moveSpeed, 0, 0);
                if(Input.GetKeyDown("left")){
                    FindObjectOfType<AudioManager>().Play("Moving");
                }
        }

        //Makes character jump
        if(Input.GetKeyDown(KeyCode.Space)){
            if(jumped == false){
                body.AddForce(0, jumpDir * moveSpeed, 0);
                body.velocity = new Vector3(0, jumpDir * moveSpeed, 0);
                FindObjectOfType<AudioManager>().Play("Jump");
                jumped = true;
            }
        }
/*
        //Makes character jump with mouse left click
        if(Input.GetKey("mouse 0") && jumped == false){
            body.AddForce(0, jumpDir * moveSpeed, 0);
            body.velocity = new Vector3(0, jumpDir * moveSpeed, 0);
            jumped = true;
        }
        */
    }

    //Collision detection
    private void OnCollisionEnter(Collision infoEntered){
        if(infoEntered.collider.tag == "Ground" && jumped == true){
            Invoke("Reset", .25f);
        }
    }

    //Counter reset
    private void Reset(){
        jumped = false;
    }
}

